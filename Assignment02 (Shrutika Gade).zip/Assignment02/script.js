$(document).ready(function () {
    // Load dynamic content for SDP tab
    $('#sdp').html('<p>This is dynamically loaded content for SDP.</p>');

    // Load dynamic content for EDI tab
    $('#edi').html('<p>This is dynamically loaded content for EDI.</p>');

    // Load dynamic content for DT tab
    $('#dt').html('<p>This is dynamically loaded content for DT.</p>');

    // Load dynamic content for Course Projects tab
    $('#course').html('<p>This is dynamically loaded content for Course Projects.</p>');
});
